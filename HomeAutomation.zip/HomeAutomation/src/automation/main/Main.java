package automation.main;

import java.util.Scanner;

public class Main {
    public static void Main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Management m = new Management();
        boolean exit = false;
        int option;

        do {
            m.menu();
            System.out.println();
            option = sc.nextInt();
            switch (option) {
                case 1:
                    m.winterMode();
                    break;
                case 2:
                    m.summerMode();
                    break;
                case 3:
                    m.cookingMode();
                    break;
                case 4:
                    m.closeEverything();
                    break;
                case 5:
                    m.showStatus();
                    break;
                case 0:
                    exit = true;
                    break;
                default:
                    System.out.println("Option wrong");
            }
        } while (exit == false);
    }
}
