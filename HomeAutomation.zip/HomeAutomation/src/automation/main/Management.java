package automation.main;

import automation.data.*;


public class Management {

    AutomationElement[] automation = new AutomationElement[10];
    Blind blind1 = new Blind("Blind kitchen", 40);
    Blind blind2 = new Blind("Blind living room", 40);

    automation[0] = new Window("Room window",blind1, false);
    automation[1] = new Window("Living room window", blind2, true);
    automation[2] = new Awning("Terrace awning", 20);
    automation[3] = new Door("Main door", true);
    automation[4] = new GarageDoor("Garage door", true, 40);
    automation[5] = new Ligth("Kitchen light", true);
    automation[6] = new Heating("Room heating", 23);
    automation[7] = new Oven("Kitchen oven", 180, true);
    automation[8] = new Ligth("Room light", true);
    automation[9] = new Heating("Bathroom heating" , 21, false);

    public void menu(){
        System.out.println("1. Winter mode.");
        System.out.println("2. Summer mode.");
        System.out.println("3. Cooking mode.");
        System.out.println("4. Close everything.");
        System.out.println("5. Show Status.");
        System.out.println("0. Exit.");
        System.out.println("Select an option:");
    }
    public void winterMode(){
            automation[3].lock();
            automation[0].lock();
            automation[1].lock();
            automation[4].lower();
            automation[0].blind1(80);
            automation[1].blind2.(80);
            automation[2].raise();
            automation[5].switchOn();
            automation[8].switchOn();
            automation[6].switchOn();
            automation[9].switchOn();
            automation[6].setTemperature(25);
            automation[9].setTemperature(25);

    }

    public void summerMode(){
        automation[3].unlock();
        automation[0].unlock();
        automation[1].unlock();
        automation[4].raiser();
        automation[0].blind1(50);
        automation[1].blind2.(50);
        automation[2].raise(50);
        automation[5].switchOff();
        automation[8].switchOff();
        automation[6].switchOff();
        automation[9].switchOff();
        automation[7].switchOff();
        automation[6].setTemperature(25);
        automation[9].setTemperature(25);
    }

    public void cookingMode(){
        automation[5].switchOn();
        automation[7].switchOn();
        automation[7].setTemperature(200);
        automation[8].switchOff();
    }

    public void closeEverything(){
        automation[3].lock();
        automation[4].lower();
        automation[2].lower();
        automation[0].lower();//persianas
        automation[1].lower();//persinas
        automation[5].switchOff();
        automation[6].switchOff();
        automation[7].switchOff();
        automation[8].switchOff();
        automation[9].switchOff();
    }

    public void showStatus(){
        System.out.println("Overall status of the house: ");
        for(int i = 0; i < automation.length; i++){
            System.out.println(automation[i]);
        }

    }
}
