package automation.data;

public interface lock {
}
