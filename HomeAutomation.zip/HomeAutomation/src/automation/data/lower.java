package automation.data;

public interface lower {
}
