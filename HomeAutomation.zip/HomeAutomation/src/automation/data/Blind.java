package automation.data;

public class Blind extends AutomationElement implements raise, lower{

    private int percent;

    public Blind(String name, int percent) {
        super(name);
        this.percent = percent;
    }

    public int getPercent() {
        return percent;
    }

    void raise(){
        percent = 100;
    }

    void lower(){
        percent = 0;
    }

    void raise(int percent){
        percent = percent + percent;
        if (percent > 100){
            percent = 100;
        }
    }

    void lower(int percent){
        percent = percent - percent;
        if (percent < 0){
            percent = 0;
        }
    }

    @Override
    public String toString() {
        return super.toString() + getPercent();
    }
}
