package automation.data;

public class Door extends AutomationElement implements lock, unlock{
    private boolean status;

    public Door(String name, boolean status) {
        super(name);
        this.status = status;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    void lock(){
        status = true;
    }

    void unlock(){
        status = false;
    }

    @Override
    public String toString() {
        return super.toString() + getStatus();
    }
}
