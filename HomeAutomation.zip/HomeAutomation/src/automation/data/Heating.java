package automation.data;

public class Heating extends AutomationElement implements switchOff, switchOn{
    private int temperature;
    private boolean status;

    public Heating(String name, int temperature) {
        super(name);
        this.temperature = temperature;
        this.status = false;
    }

    public Heating(String name, int temperature, boolean status) {
        super(name);
        this.temperature = temperature;
        this.status = status;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    public boolean getStatus() {
        return status;
    }

    void switchOn(){
        status = true;
    }

    void switchOff(){
        status = false;
    }

    @Override
    public String toString() {
        return super.toString() + getTemperature() + getStatus();
    }
}
