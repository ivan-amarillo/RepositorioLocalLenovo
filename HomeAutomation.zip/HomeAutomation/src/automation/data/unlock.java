package automation.data;

public interface unlock {
}
