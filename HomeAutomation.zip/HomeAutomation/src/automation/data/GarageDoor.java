package automation.data;

public class GarageDoor extends Door implements raise, lower, unlock, lock{

    private int percent;

    public GarageDoor(String name, boolean status, int percent) {
        super(name, status);
        this.percent = percent;
    }

    public int getPercent() {
        return percent;
    }
    void lock(){
        setStatus(true);
    }

    void unlock(){
        setStatus(false);
    }

    void raise(){
        percent = 100;
    }

    void lower(){
        percent = 0;
    }

    void raise(int percent){
        percent = percent + percent;
        if (percent > 100){
            percent = 100;
        }
    }

    void lower(int percent){
        percent = percent - percent;
        if (percent < 0){
            percent = 0;
        }
    }

    @Override
    public String toString() {
        return super.toString() + getStatus() + getPercent();
    }
}
