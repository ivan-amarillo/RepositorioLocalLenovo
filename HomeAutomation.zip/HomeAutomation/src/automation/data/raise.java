package automation.data;

public interface raise {
}
