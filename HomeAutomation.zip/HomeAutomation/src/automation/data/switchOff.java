package automation.data;

public interface switchOff {
}
