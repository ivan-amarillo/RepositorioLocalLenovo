package automation.data;

public class Window extends AutomationElement implements lock, unlock{

    Blind blind;
    private boolean status;

    public Window(String name, Blind blind, boolean status) {
        super(name);
        this.blind = blind;
        this.status = status;
    }

    public Blind getBlind() {
        return blind;
    }

    void lock(){
        status = true;
    }

    void unlock(){
        status = false;
    }

    public boolean getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return super.toString() + blind + status;
    }
}
