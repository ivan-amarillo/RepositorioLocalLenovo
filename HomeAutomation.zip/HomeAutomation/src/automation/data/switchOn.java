package automation.data;

public interface switchOn {
}
