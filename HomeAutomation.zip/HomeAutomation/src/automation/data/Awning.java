package automation.data;

public class Awning extends Blind{
    public Awning(String name, int percent) {
        super(name, percent);
    }

    @Override
    public String toString() {
        return super.toString() + getPercent();
    }
}
