package automation.data;

public class Oven extends Heating{
    public Oven(String name, int temperature) {
        super(name, temperature);
    }

    public Oven(String name, int temperature, boolean status) {
        super(name, temperature, status);
    }
}
