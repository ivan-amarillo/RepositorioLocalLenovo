package automation.data;

public class Light extends AutomationElement implements switchOff, switchOn{

    private boolean status;

    public Light(String name, boolean status) {
        super(name);
        this.status = status;
    }

    public boolean getStatus() {
        return status;
    }

    public void switchOn(){
        status = true;
    }

    void switchOff(){
        status = false;
    }

    @Override
    public String toString() {
        return super.toString() + status;
    }
}
